﻿namespace Qulinlin.IdentityModel.Extensions.AccountManager;

public class Class1
{

}
