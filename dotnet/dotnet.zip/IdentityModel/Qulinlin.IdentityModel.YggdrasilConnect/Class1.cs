﻿namespace Qulinlin.IdentityModel.YggdrasilConnect;

public class Class1
{

}
