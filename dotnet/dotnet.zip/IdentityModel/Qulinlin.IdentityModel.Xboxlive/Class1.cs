﻿namespace Qulinlin.IdentityModel.Xboxlive;

public class Class1
{

}
