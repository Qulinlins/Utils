namespace Qulinlin.IdentityModel.OAuth.Abstractions;

public interface ICredentialStore{}