﻿namespace Qulinlin.IdentityModel.Yggdrasil;

public class Class1
{

}
