﻿namespace Qulinlin.IdentityModel.OpenId;

public class Class1
{

}
