﻿namespace Qulinlin.IdentityModel.Extensions.Pkce;

public class Class1
{

}
