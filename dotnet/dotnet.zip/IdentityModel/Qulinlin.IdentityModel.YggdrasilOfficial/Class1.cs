﻿namespace Qulinlin.IdentityModel.YggdrasilOfficial;

public class Class1
{

}
