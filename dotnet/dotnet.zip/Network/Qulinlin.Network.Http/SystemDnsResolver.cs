using Qulinlin.Network.Http.Abstractions;

namespace Qulinlin.Network.Http;

public class SystemDnsResolver : DnsResolver
{
    
}