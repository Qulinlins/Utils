﻿namespace Qulinlin.Network.Ftp;

public class Class1
{

}
