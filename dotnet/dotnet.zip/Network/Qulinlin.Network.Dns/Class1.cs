﻿namespace Qulinlin.Network.Dns;

public class Class1
{

}
