﻿namespace Qulinlin.Network.Mail;

public class Class1
{

}
